import javax.swing.*;

public class MainFrame {
    private JPanel PainelPrincipal;
    private JPasswordField SPSenha;
    private JTextField TFUsuario;
    private JPanel JPDados;
    private JPanel JPFuncoes;


}
